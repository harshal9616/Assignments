package com.yash.tdd.testcase;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yash.tddassignment.Que6;

public class Que6TestCase {

	@Test
	public void test() {
		assertEquals(true,Que6.countvowel("Rahul"));
	}


}
