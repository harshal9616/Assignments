package com.yash.tdd.testcase;

import static org.junit.Assert.*;

import org.junit.Test;

import com.yash.tddassignment.Que1;

public class Que1TestCase {

	@Test
	public void test() {
		assertEquals(9,Que1.HCF(81,72));	
	}

}
