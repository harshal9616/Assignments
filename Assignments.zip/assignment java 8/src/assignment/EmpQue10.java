package assignment;

public class EmpQue10 {

	
		String Name;
		int Id;
		
		public EmpQue10 (String Name, int Id) {

		this.Name = Name;
		this.Id = Id;

		}
		public String getName() {
		return Name;
		}
		public void setName(String Name) {
		this.Name = Name;
		}
		public int getId() {
		return Id;
		}
		public void setId(int Id) {
		this.Id = Id;
		}

		}
	

