package assignment;

public class Que7 {

}
